# Davidgistmediang

A responsive professional news-site starter.

## Included
- Responsive homepage
- Empty newsroom (no articles uploaded)
- News categories
- About section
- Contact form placeholder
- TikTok, Instagram and YouTube links
- Mobile navigation
- No external libraries required

## Run
Open `index.html` in a browser.

## Before going live
Connect the contact form to an email/backend service and add your own verified news content.
